﻿namespace WindowsFormsApplication4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.generateButton = new System.Windows.Forms.Button();
            this.topRedRadioButton = new System.Windows.Forms.RadioButton();
            this.topBlueRadioButton = new System.Windows.Forms.RadioButton();
            this.topGreenRadioButton = new System.Windows.Forms.RadioButton();
            this.topPurpleRadioButton = new System.Windows.Forms.RadioButton();
            this.topOrangeRadioButton = new System.Windows.Forms.RadioButton();
            this.botBlueRadioButton = new System.Windows.Forms.RadioButton();
            this.botRedRadioButton = new System.Windows.Forms.RadioButton();
            this.botGreenRadioButton = new System.Windows.Forms.RadioButton();
            this.botPurpleRadioButton = new System.Windows.Forms.RadioButton();
            this.botOrangeRadioButton = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.topDefaultRadioButton = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.botDefaultRadioButton = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(700, 700);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // generateButton
            // 
            this.generateButton.Location = new System.Drawing.Point(769, 90);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(267, 63);
            this.generateButton.TabIndex = 1;
            this.generateButton.Text = "Generate Levy C Curve";
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.generateButton_Click);
            // 
            // topRedRadioButton
            // 
            this.topRedRadioButton.AutoSize = true;
            this.topRedRadioButton.Location = new System.Drawing.Point(4, 9);
            this.topRedRadioButton.Name = "topRedRadioButton";
            this.topRedRadioButton.Size = new System.Drawing.Size(45, 17);
            this.topRedRadioButton.TabIndex = 2;
            this.topRedRadioButton.TabStop = true;
            this.topRedRadioButton.Text = "Red";
            this.topRedRadioButton.UseVisualStyleBackColor = true;
            // 
            // topBlueRadioButton
            // 
            this.topBlueRadioButton.AutoSize = true;
            this.topBlueRadioButton.Location = new System.Drawing.Point(4, 32);
            this.topBlueRadioButton.Name = "topBlueRadioButton";
            this.topBlueRadioButton.Size = new System.Drawing.Size(46, 17);
            this.topBlueRadioButton.TabIndex = 3;
            this.topBlueRadioButton.TabStop = true;
            this.topBlueRadioButton.Text = "Blue";
            this.topBlueRadioButton.UseVisualStyleBackColor = true;
            // 
            // topGreenRadioButton
            // 
            this.topGreenRadioButton.AutoSize = true;
            this.topGreenRadioButton.Location = new System.Drawing.Point(4, 55);
            this.topGreenRadioButton.Name = "topGreenRadioButton";
            this.topGreenRadioButton.Size = new System.Drawing.Size(54, 17);
            this.topGreenRadioButton.TabIndex = 5;
            this.topGreenRadioButton.TabStop = true;
            this.topGreenRadioButton.Text = "Green";
            this.topGreenRadioButton.UseVisualStyleBackColor = true;
            // 
            // topPurpleRadioButton
            // 
            this.topPurpleRadioButton.AutoSize = true;
            this.topPurpleRadioButton.Location = new System.Drawing.Point(4, 78);
            this.topPurpleRadioButton.Name = "topPurpleRadioButton";
            this.topPurpleRadioButton.Size = new System.Drawing.Size(55, 17);
            this.topPurpleRadioButton.TabIndex = 6;
            this.topPurpleRadioButton.TabStop = true;
            this.topPurpleRadioButton.Text = "Purple";
            this.topPurpleRadioButton.UseVisualStyleBackColor = true;
            // 
            // topOrangeRadioButton
            // 
            this.topOrangeRadioButton.AutoSize = true;
            this.topOrangeRadioButton.Location = new System.Drawing.Point(4, 101);
            this.topOrangeRadioButton.Name = "topOrangeRadioButton";
            this.topOrangeRadioButton.Size = new System.Drawing.Size(60, 17);
            this.topOrangeRadioButton.TabIndex = 7;
            this.topOrangeRadioButton.TabStop = true;
            this.topOrangeRadioButton.Text = "Orange";
            this.topOrangeRadioButton.UseVisualStyleBackColor = true;
            // 
            // botBlueRadioButton
            // 
            this.botBlueRadioButton.AutoSize = true;
            this.botBlueRadioButton.Location = new System.Drawing.Point(3, 31);
            this.botBlueRadioButton.Name = "botBlueRadioButton";
            this.botBlueRadioButton.Size = new System.Drawing.Size(46, 17);
            this.botBlueRadioButton.TabIndex = 8;
            this.botBlueRadioButton.TabStop = true;
            this.botBlueRadioButton.Text = "Blue";
            this.botBlueRadioButton.UseVisualStyleBackColor = true;
            // 
            // botRedRadioButton
            // 
            this.botRedRadioButton.AutoSize = true;
            this.botRedRadioButton.Location = new System.Drawing.Point(3, 9);
            this.botRedRadioButton.Name = "botRedRadioButton";
            this.botRedRadioButton.Size = new System.Drawing.Size(45, 17);
            this.botRedRadioButton.TabIndex = 9;
            this.botRedRadioButton.TabStop = true;
            this.botRedRadioButton.Text = "Red";
            this.botRedRadioButton.UseVisualStyleBackColor = true;
            // 
            // botGreenRadioButton
            // 
            this.botGreenRadioButton.AutoSize = true;
            this.botGreenRadioButton.Location = new System.Drawing.Point(3, 54);
            this.botGreenRadioButton.Name = "botGreenRadioButton";
            this.botGreenRadioButton.Size = new System.Drawing.Size(54, 17);
            this.botGreenRadioButton.TabIndex = 10;
            this.botGreenRadioButton.TabStop = true;
            this.botGreenRadioButton.Text = "Green";
            this.botGreenRadioButton.UseVisualStyleBackColor = true;
            // 
            // botPurpleRadioButton
            // 
            this.botPurpleRadioButton.AutoSize = true;
            this.botPurpleRadioButton.Location = new System.Drawing.Point(3, 78);
            this.botPurpleRadioButton.Name = "botPurpleRadioButton";
            this.botPurpleRadioButton.Size = new System.Drawing.Size(55, 17);
            this.botPurpleRadioButton.TabIndex = 11;
            this.botPurpleRadioButton.TabStop = true;
            this.botPurpleRadioButton.Text = "Purple";
            this.botPurpleRadioButton.UseVisualStyleBackColor = true;
            // 
            // botOrangeRadioButton
            // 
            this.botOrangeRadioButton.AutoSize = true;
            this.botOrangeRadioButton.Location = new System.Drawing.Point(3, 101);
            this.botOrangeRadioButton.Name = "botOrangeRadioButton";
            this.botOrangeRadioButton.Size = new System.Drawing.Size(60, 17);
            this.botOrangeRadioButton.TabIndex = 12;
            this.botOrangeRadioButton.TabStop = true;
            this.botOrangeRadioButton.Text = "Orange";
            this.botOrangeRadioButton.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.topDefaultRadioButton);
            this.panel1.Controls.Add(this.topRedRadioButton);
            this.panel1.Controls.Add(this.topBlueRadioButton);
            this.panel1.Controls.Add(this.topGreenRadioButton);
            this.panel1.Controls.Add(this.topPurpleRadioButton);
            this.panel1.Controls.Add(this.topOrangeRadioButton);
            this.panel1.Location = new System.Drawing.Point(769, 228);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(97, 153);
            this.panel1.TabIndex = 13;
            // 
            // topDefaultRadioButton
            // 
            this.topDefaultRadioButton.AutoSize = true;
            this.topDefaultRadioButton.Location = new System.Drawing.Point(4, 125);
            this.topDefaultRadioButton.Name = "topDefaultRadioButton";
            this.topDefaultRadioButton.Size = new System.Drawing.Size(86, 17);
            this.topDefaultRadioButton.TabIndex = 8;
            this.topDefaultRadioButton.TabStop = true;
            this.topDefaultRadioButton.Text = "Default Color";
            this.topDefaultRadioButton.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.botDefaultRadioButton);
            this.panel2.Controls.Add(this.botOrangeRadioButton);
            this.panel2.Controls.Add(this.botPurpleRadioButton);
            this.panel2.Controls.Add(this.botGreenRadioButton);
            this.panel2.Controls.Add(this.botRedRadioButton);
            this.panel2.Controls.Add(this.botBlueRadioButton);
            this.panel2.Location = new System.Drawing.Point(940, 228);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(96, 153);
            this.panel2.TabIndex = 14;
            // 
            // botDefaultRadioButton
            // 
            this.botDefaultRadioButton.AutoSize = true;
            this.botDefaultRadioButton.Location = new System.Drawing.Point(4, 125);
            this.botDefaultRadioButton.Name = "botDefaultRadioButton";
            this.botDefaultRadioButton.Size = new System.Drawing.Size(86, 17);
            this.botDefaultRadioButton.TabIndex = 13;
            this.botDefaultRadioButton.TabStop = true;
            this.botDefaultRadioButton.Text = "Default Color";
            this.botDefaultRadioButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(770, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Top Color";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(941, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Bottom Color";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1099, 719);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.generateButton);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.RadioButton topRedRadioButton;
        private System.Windows.Forms.RadioButton topBlueRadioButton;
        private System.Windows.Forms.RadioButton topGreenRadioButton;
        private System.Windows.Forms.RadioButton topPurpleRadioButton;
        private System.Windows.Forms.RadioButton topOrangeRadioButton;
        private System.Windows.Forms.RadioButton botBlueRadioButton;
        private System.Windows.Forms.RadioButton botRedRadioButton;
        private System.Windows.Forms.RadioButton botGreenRadioButton;
        private System.Windows.Forms.RadioButton botPurpleRadioButton;
        private System.Windows.Forms.RadioButton botOrangeRadioButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton topDefaultRadioButton;
        private System.Windows.Forms.RadioButton botDefaultRadioButton;
    }
}

